package jxl.write;

public final class BoldStyle extends jxl.format.BoldStyle {
	private BoldStyle(int val) {
		super(0, "");
	}
}