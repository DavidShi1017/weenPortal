package jxl.write;

import jxl.CellView;
import jxl.Range;
import jxl.Sheet;
import jxl.format.CellFormat;
import jxl.format.PageOrientation;
import jxl.format.PaperSize;
import jxl.write.biff.RowsExceededException;

public interface WritableSheet extends Sheet {
	void addCell(WritableCell var1) throws WriteException, RowsExceededException;

	void setName(String var1);

	void setHidden(boolean var1);

	void setProtected(boolean var1);

	void setColumnView(int var1, int var2);

	void setColumnView(int var1, int var2, CellFormat var3);

	void setColumnView(int var1, CellView var2);

	void setRowView(int var1, int var2) throws RowsExceededException;

	void setRowView(int var1, boolean var2) throws RowsExceededException;

	void setRowView(int var1, int var2, boolean var3) throws RowsExceededException;

	WritableCell getWritableCell(int var1, int var2);

	WritableCell getWritableCell(String var1);

	WritableHyperlink[] getWritableHyperlinks();

	void insertRow(int var1);

	void insertColumn(int var1);

	void removeColumn(int var1);

	void removeRow(int var1);

	Range mergeCells(int var1, int var2, int var3, int var4) throws WriteException, RowsExceededException;

	void unmergeCells(Range var1);

	void addHyperlink(WritableHyperlink var1) throws WriteException, RowsExceededException;

	void removeHyperlink(WritableHyperlink var1);

	void removeHyperlink(WritableHyperlink var1, boolean var2);

	void setHeader(String var1, String var2, String var3);

	void setFooter(String var1, String var2, String var3);

	void setPageSetup(PageOrientation var1);

	void setPageSetup(PageOrientation var1, double var2, double var4);

	void setPageSetup(PageOrientation var1, PaperSize var2, double var3, double var5);

	void addRowPageBreak(int var1);

	void addImage(WritableImage var1);

	int getNumberOfImages();

	WritableImage getImage(int var1);

	void removeImage(WritableImage var1);
}