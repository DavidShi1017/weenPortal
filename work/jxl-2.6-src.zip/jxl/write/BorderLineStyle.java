package jxl.write;

public final class BorderLineStyle extends jxl.format.BorderLineStyle {
	private BorderLineStyle() {
		super(0, (String) null);
	}
}