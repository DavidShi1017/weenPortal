package jxl.write;

import java.util.Collection;
import jxl.CellFeatures;
import jxl.biff.BaseCellFeatures;
import jxl.biff.BaseCellFeatures.ValidationCondition;

public class WritableCellFeatures extends CellFeatures {
	public static final ValidationCondition BETWEEN;
	public static final ValidationCondition NOT_BETWEEN;
	public static final ValidationCondition EQUAL;
	public static final ValidationCondition NOT_EQUAL;
	public static final ValidationCondition GREATER_THAN;
	public static final ValidationCondition LESS_THAN;
	public static final ValidationCondition GREATER_EQUAL;
	public static final ValidationCondition LESS_EQUAL;

	public WritableCellFeatures() {
	}

	public WritableCellFeatures(CellFeatures cf) {
		super(cf);
	}

	public void setComment(String s) {
		super.setComment(s);
	}

	public void setComment(String s, double width, double height) {
		super.setComment(s, width, height);
	}

	public void removeComment() {
		super.removeComment();
	}

	public void setDataValidationList(Collection c) {
		super.setDataValidationList(c);
	}

	public void setDataValidationRange(int col1, int row1, int col2, int row2) {
		super.setDataValidationRange(col1, row1, col2, row2);
	}

	public void setNumberValidation(double val, ValidationCondition c) {
		super.setNumberValidation(val, c);
	}

	public void setNumberValidation(double val1, double val2, ValidationCondition c) {
		super.setNumberValidation(val1, val2, c);
	}

	static {
		BETWEEN = BaseCellFeatures.BETWEEN;
		NOT_BETWEEN = BaseCellFeatures.NOT_BETWEEN;
		EQUAL = BaseCellFeatures.EQUAL;
		NOT_EQUAL = BaseCellFeatures.NOT_EQUAL;
		GREATER_THAN = BaseCellFeatures.GREATER_THAN;
		LESS_THAN = BaseCellFeatures.LESS_THAN;
		GREATER_EQUAL = BaseCellFeatures.GREATER_EQUAL;
		LESS_EQUAL = BaseCellFeatures.LESS_EQUAL;
	}
}