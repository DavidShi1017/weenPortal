package jxl.write;

public final class Colour extends jxl.format.Colour {
	private Colour() {
		super(0, (String) null, 0, 0, 0);
	}
}