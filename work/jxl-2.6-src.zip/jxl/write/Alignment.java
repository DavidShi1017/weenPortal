package jxl.write;

public final class Alignment extends jxl.format.Alignment {
	private Alignment() {
		super(0, (String) null);
	}
}