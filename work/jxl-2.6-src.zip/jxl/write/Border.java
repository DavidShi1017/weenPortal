package jxl.write;

public final class Border extends jxl.format.Border {
	private Border() {
		super((String) null);
	}
}