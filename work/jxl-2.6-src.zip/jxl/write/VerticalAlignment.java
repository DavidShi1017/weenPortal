package jxl.write;

public final class VerticalAlignment extends jxl.format.VerticalAlignment {
	private VerticalAlignment() {
		super(0, (String) null);
	}
}