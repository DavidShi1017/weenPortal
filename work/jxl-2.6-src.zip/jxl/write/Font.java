package jxl.write;

import jxl.format.Colour;
import jxl.format.ScriptStyle;
import jxl.format.UnderlineStyle;
import jxl.write.WritableFont.BoldStyle;
import jxl.write.WritableFont.FontName;

public class Font extends WritableFont {

	public static final FontName ARIAL;

	public static final FontName TIMES;

	public static final BoldStyle NO_BOLD;

	public static final BoldStyle BOLD;

	public static final UnderlineStyle NO_UNDERLINE;

	public static final UnderlineStyle SINGLE;

	public static final UnderlineStyle DOUBLE;

	public static final UnderlineStyle SINGLE_ACCOUNTING;

	public static final UnderlineStyle DOUBLE_ACCOUNTING;
	public static final ScriptStyle NORMAL_SCRIPT;
	public static final ScriptStyle SUPERSCRIPT;
	public static final ScriptStyle SUBSCRIPT;

	public Font(FontName fn) {
		super(fn);
	}

	public Font(FontName fn, int ps) {
		super(fn, ps);
	}

	public Font(FontName fn, int ps, BoldStyle bs) {
		super(fn, ps, bs);
	}

	public Font(FontName fn, int ps, BoldStyle bs, boolean italic) {
		super(fn, ps, bs, italic);
	}

	public Font(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us) {
		super(fn, ps, bs, it, us);
	}

	public Font(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us, Colour c) {
		super(fn, ps, bs, it, us, c);
	}

	public Font(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us, Colour c, ScriptStyle ss) {
		super(fn, ps, bs, it, us, c, ss);
	}

	static {
		ARIAL = WritableFont.ARIAL;
		TIMES = WritableFont.TIMES;
		NO_BOLD = WritableFont.NO_BOLD;
		BOLD = WritableFont.BOLD;
		NO_UNDERLINE = UnderlineStyle.NO_UNDERLINE;
		SINGLE = UnderlineStyle.SINGLE;
		DOUBLE = UnderlineStyle.DOUBLE;
		SINGLE_ACCOUNTING = UnderlineStyle.SINGLE_ACCOUNTING;
		DOUBLE_ACCOUNTING = UnderlineStyle.DOUBLE_ACCOUNTING;
		NORMAL_SCRIPT = ScriptStyle.NORMAL_SCRIPT;
		SUPERSCRIPT = ScriptStyle.SUPERSCRIPT;
		SUBSCRIPT = ScriptStyle.SUBSCRIPT;
	}
}