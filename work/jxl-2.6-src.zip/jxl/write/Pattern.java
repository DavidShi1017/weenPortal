package jxl.write;

public final class Pattern extends jxl.format.Pattern {
	private Pattern() {
		super(0, (String) null);
	}
}